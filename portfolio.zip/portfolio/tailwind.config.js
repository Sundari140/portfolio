/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      borderColor : {
        'primary' : '#1e40af',
        'secondary': '#2563eb'
            }
    },
    fontFamily :{
      'hero-font' : 'Sriracha'
    }
  },
  plugins: [],
}

