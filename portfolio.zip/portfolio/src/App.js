import './App.css';
import About from './Components/About';
import Header from './Components/Header';
import Hero from './Components/Hero';
import Task from './Components/Task';
import Resume from './Components/Resume';
import Contact from './Components/Contact';
import Footer from './Components/Footer';

function App() {
  return (
    <div>

      <Header />
      <Hero />
      <About />
      <Task />
      <Resume />
      <Contact />
      <Footer />

    </div>
  );
}

export default App;
