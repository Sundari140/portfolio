import React from 'react'
import Heroimg from '../Assets/hero.png'

export default function Hero() {
    return (
        <div id="Hero" className='flex flex-col md:flex-row px-3 py-32 bg-primary justify-center'>
            <div className='md:w-1/3 flex flex-col'>
                <h1 className=' text-white text-4xl font-hero-font md:py-32'>Hi,<br /> I am Sundari
                    <p className='text-2xl'>Im a Frontend Developer</p>
                </h1>
            </div>
            <img className='md:w-1/3' src={Heroimg} />
        </div>
    )
}
