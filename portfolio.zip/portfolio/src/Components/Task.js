import websiteimg1 from '../Assets/food.png'
import websiteimg2 from '../Assets/netflix-clone.png'
import websiteimg3 from '../Assets/ecommerce.jpeg'


export default function Task(){
    return(
        <section id="Task" className='flex flex-col py-20 px-5 justify-center bg-primary'>
            <div className='w-full'>
                <div className='flex flex-col px-10 py-5'>
                <h1  className='text-4xl border-b-4 border-secondary mb-5 w-[150px] font-bold text-white'>Heading</h1>
            <p className='text-white'>These are some of my tasks. I have build these with HTML, CSS, Tailwind CSS, Javascript, React. </p>
            </div>
            </div>

            <div  className='w-full font-hero-font font-bold'>

                <div className=' flex flex-col md:flex-row px-10 gap-5'>
                <div className='relative'>
                <img className='h-[200px]' src={websiteimg1}  />
                <div className='project'>
                    <p className='text-center px-5 py-5'>Its a food e-commerce website.Build with React.js</p>
                </div>
                </div>
              
                <div className='relative'>
                <img className='h-[200px]' src={websiteimg2}  />
                <div className='project'>
                    <p className='text-center px-5 py-5'>Its a netflix clone. Build with HTML and CSS.</p>
                </div>
                </div>

                <div className='relative'>
                <img className='h-[200px]' src={websiteimg3}  />
                <div className='project'>
                    <p className='text-center px-5 py-5'>Its a ecommerce website. Build with React.js.</p>
                </div>
                </div>

                </div>

            </div>
        </section>
    )
}