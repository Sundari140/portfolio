import React from 'react'

export default function Footer() {
  return (
    <div className='py-4 bg-secondary text-center text-white'>
      &copy; Sundari 2024
    </div>
  )
}
